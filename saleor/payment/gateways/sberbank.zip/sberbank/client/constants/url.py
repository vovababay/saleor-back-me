class URL(object):
    BASE_URL = 'https://securepayments.sberbank.ru/payment/rest'
    SANDBOX_URL = 'https://3dsec.sberbank.ru/payment/rest'
    REGISTER_URL = '/register.do'
    STATUS_URL = '/getOrderStatusExtended.do'
