import logging

from ...interface import (
    GatewayConfig,
    GatewayResponse,
    PaymentData,
    PaymentMethodInfo,

)
from decimal import Decimal
from typing import Dict
from ...utils import create_transaction, TransactionKind
from ... import ChargeStatus, TransactionKind
from ...models import Payment

from .forms import SberbankPaymentForm
from . import errors
from .utils import (
    get_amount_for_sberbank,
    get_error_response,
    get_return_url,
    get_data_for_payment)

from . import client as sberbank

from .tasks import check_status_sberbank_task

# The list of currencies supported by razorpay
#SUPPORTED_CURRENCIES = ("USD",)
SUPPORTED_CURRENCIES = ("USD")
# Define what are the Sberbank exceptions,
# as the Sberbank provider doesn't define a base exception as of now.
SBERBANK_EXCEPTIONS = (
    sberbank.errors.BadRequestError,
    sberbank.errors.GatewayError,
    sberbank.errors.ServerError,
)

# Get the logger for this file, it will allow us to log
# error responses from Sberbank.
logger = logging.getLogger(__name__)

def _generate_response(
    payment_information: PaymentData, kind: str, data: Dict
) -> GatewayResponse:
    """Generate Saleor transaction information from the payload or from passed data."""
    return GatewayResponse(
        transaction_id=data.get("id", payment_information.token),
        action_required=False,
        kind=kind,
        amount=data.get("amount", payment_information.amount),
        currency=data.get("currency", payment_information.currency),
        error=data.get("error"),
        is_success=data.get("is_success", True),
        raw_response=data,
    )


def get_error_message_from_sberbank_error(exc: BaseException):
    """Convert a Razorpay error to a user-friendly error message.

    It also logs the exception to stderr.
    """
    logger.exception(exc)
    if isinstance(exc, sberbank.errors.BadRequestError):
        return errors.INVALID_REQUEST
    else:
        return errors.SERVER_ERROR


def create_form(data, payment_information, connection_params):
    """Return the associated Sberbank payment form."""
    sberbank_payment_id, sberbank_payment_url = get_sberbank_register_info(payment_information,
                                                                           connection_params)

    form = SberbankPaymentForm(
        data=data,
        payment_information=payment_information,
        connection_params=connection_params,
        initial={
            'sberbank_payment_id': sberbank_payment_id,
        },
    )

    form.sberbank_payment_url = sberbank_payment_url

    return form


def get_sberbank_register_info(payment_information, connection_params):
    sberbank_client = get_client(connection_params)

    try:

        response = sberbank_client.payment.register(order_id=payment_information.order_id,
                                                    amount=get_amount_for_sberbank(payment_information.amount),
                                                    return_url=get_return_url(payment_information.order_id),
                                                    data=get_data_for_payment(payment_information))

        # orderId есть только у успешно зарегистрированных заказов
        if 'orderId' in response:
            # Создадим транзакцию, которую будем обновлять фоновым заданием
            token = response['orderId']
            payment_information.token = token
            txn = create_transaction(
                payment=Payment.objects.get(order_id=payment_information.order_id),
                kind=TransactionKind.CAPTURE,
                payment_information=payment_information,
            )

            check_status_sberbank_task.delay(order_id=token,
                                             connection_params=connection_params)
            return token, response['formUrl']

        if 'errorCode' in response:
            error_code = int(response['errorCode'])
            if error_code in errors.ERRORS:
                error_msg = response['errorMessage']
                logger.critical('{}:{}'.format(error_code, error_msg))
                raise Exception(error_msg)

    except SBERBANK_EXCEPTIONS as exc:
        error = get_error_message_from_sberbank_error(exc)
        response = get_error_response(
            payment_information.amount, error=error, id=payment_information.order_id
        )


def check_payment_supported(payment_information: PaymentData):
    """Check that a given payment is supported."""
    if payment_information.currency not in SUPPORTED_CURRENCIES:
        return errors.UNSUPPORTED_CURRENCY % {"currency": payment_information.currency}

def clean_razorpay_response(response: Dict):
    """Convert the Razorpay response to our internal representation for easier processing.

    As the Razorpay response payload contains the final amount
    in Indian rupees, we convert the amount to paisa (by dividing by 100).
    """
    response["amount"] = Decimal(response["amount"]) / 100

def get_client(connection_params):
    """Create a Sberbank client from set-up application keys."""
    sberbank_client = sberbank.Client(auth=(connection_params['login'], connection_params['password']),
                                      sandbox=connection_params['sandbox_mode'])
    return sberbank_client

def get_error_message_from_razorpay_error(exc: BaseException):
    """Convert a Razorpay error to a user-friendly error message.

    It also logs the exception to stderr.
    """
    logger.exception(exc)
    if isinstance(exc, sberbank.errors.BadRequestError):
        return errors.INVALID_REQUEST
    else:
        return errors.SERVER_ERROR

def capture(payment_information: PaymentData, config: GatewayConfig) -> GatewayResponse:
    """Capture a authorized payment using the razorpay client.

    But it first check if the given payment instance is supported
    by the gateway.

    If an error from Razorpay occurs, we flag the transaction as failed and return
    a short user friendly description of the error after logging the error to stderr.
    """
    error = check_payment_supported(payment_information=payment_information)
    razorpay_client = get_client(**config.connection_params)
    razorpay_amount = get_amount_for_sberbank(payment_information.amount)

    if not error:
        try:
            response = razorpay_client.payment.capture(
                payment_information.token, razorpay_amount
            )
            clean_razorpay_response(response)
        except SBERBANK_EXCEPTIONS as exc:
            error = get_error_message_from_razorpay_error(exc)
            response = get_error_response(
                payment_information.amount, error=error, id=payment_information.token
            )
    else:
        response = get_error_response(
            payment_information.amount, error=error, id=payment_information.token
        )

    return _generate_response(
        payment_information=payment_information,
        kind=TransactionKind.CAPTURE,
        data=response,
    )

def dummy_success():
    return True

def authorize(
    payment_information: PaymentData, config: GatewayConfig
) -> GatewayResponse:
    success = dummy_success()
    error = None
    if not success:
        error = "Unable to authorize transaction"
    return GatewayResponse(
        is_success=success,
        action_required=False,
        kind=TransactionKind.AUTH,
        amount=payment_information.amount,
        currency=payment_information.currency,
        transaction_id=payment_information.token,
        error=error,
        payment_method_info=PaymentMethodInfo(
            last_4="1234",
            exp_year=2222,
            exp_month=12,
            brand="dummy_visa",
            name="Holder name",
            type="card",
        ),
    )


def refund(payment_information: PaymentData, config: GatewayConfig) -> GatewayResponse:
    error = None
    success = dummy_success()
    if not success:
        error = "Unable to process refund"
    return GatewayResponse(
        is_success=success,
        action_required=False,
        kind=TransactionKind.REFUND,
        amount=payment_information.amount,
        currency=payment_information.currency,
        transaction_id=payment_information.token,
        error=error,
    )


def process_payment(
    payment_information: PaymentData, config: GatewayConfig
) -> GatewayResponse:
    """Process the payment."""
    token = payment_information.token

    # Process payment normally if payment token is valid
    if token not in dict(ChargeStatus.CHOICES):
        return capture(payment_information, config)

    # Process payment by charge status which is selected in the payment form
    # Note that is for testing by dummy gateway only
    charge_status = token
    authorize_response = authorize(payment_information, config)
    if charge_status == ChargeStatus.NOT_CHARGED:
        return authorize_response

    if not config.auto_capture:
        return authorize_response

    capture_response = capture(payment_information, config)
    if charge_status == ChargeStatus.FULLY_REFUNDED:
        return refund(payment_information, config)
    return capture_response
